let express=require("express");
let rou=express.Router();

rou.use(express.json())

let zxc=require("../json/dq.json")
let jkl=require("../json/tow.json")

// rou.get("/",(req,res)=>{
//     res.send({data})
// })

rou.post('/',(reqw,res)=>{
    const data=reqw.body;
    const daan={
        "name":"销量"
    };

    if (reqw.headers['content-type'] != 'application/json') {
        res.send('请使用json数据请求');
        return;
    }
    else if (data==data) {
        // console.log(zxc);
        res.send(daan)
    }

    
})

// rou.post("/",(ver,res)=>{
//     const newList =ver.body
//     console.log(newList);
//     res.send({data})
// })

module.exports=rou;
// console.log(rou);