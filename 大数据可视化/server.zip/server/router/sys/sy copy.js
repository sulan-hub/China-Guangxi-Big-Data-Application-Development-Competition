const http =require('http')
const querystring=require('querystring')
const data=require("../json/sj.json")

const server=http.createServer((req,res)=>{
    if (req.method === 'POST') {
        let postData = '';
        req.on('data',chunk =>{
            postData += chunk.toString()
        })
        req.on('end',()=>{
            console.log('postData',postData);
            res.end({data})
        })
    }
})