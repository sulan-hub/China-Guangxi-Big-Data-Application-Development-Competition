let express=require("express");
let rou=express.Router()
let data=require("../json/sf.json")

rou.get("/",(req,res)=>{
    res.send({data})
})
rou.post("/",(ver,res)=>{
    const newList =ver.body
    console.log(newList);
    res.send({data})
})

module.exports=rou;
// console.log(rou);