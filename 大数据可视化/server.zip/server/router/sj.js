let express=require("express");
let rou=express.Router()
let data=require("../json/sj.json")

rou.get("/",(req,res)=>{
    res.send({data})
})

rou.post("/",(ver,res)=>{
    console.log(ver.body);
    res.send({data})
})


module.exports=rou;
// console.log(rou);