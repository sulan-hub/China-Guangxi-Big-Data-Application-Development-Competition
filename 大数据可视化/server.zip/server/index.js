let express=require("express");
let body=require('body-parser');
let cors=require('cors');
const app=express();

app.use(body.json());
app.use(body.urlencoded({extended:true}));
app.use(cors());

let chat=require("./router/tow");
let ch=require("./router/sf")
let nm=require("./router/dq")
let bn=require("./router/dd")
let bna=require("./router/sj")
// let lk=require("./router/sy")

app.use("/tow",chat)
app.use("/sf",ch)
app.use("/dq",nm)
app.use("/dd",bn)
app.use("/sj",bna)
// app.use("/sys",lk)

var ip='127.0.0.1'
var port=9978
app.listen(port,ip,()=>{
console.log("ok\nip为"+ip+":"+port)
});